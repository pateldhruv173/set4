package com.dp.demosqlite

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.myrecyclestruct.view.*

class MyAdapter (val context: Context, var arr:ArrayList<vehicle>)
    : RecyclerView.Adapter<MyAdapter.ViewHolder>()

{
    class ViewHolder(var view: View):RecyclerView.ViewHolder(view)
    {
        fun bind(p:vehicle)
        {
            view.txtRecyclerId.setText(p.id.toString())
            view.txtRecyclerName.setText(p.vname.toString())
            view.txtRecyclerAge.setText(p.millage.toString())
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var inflater=LayoutInflater.from(parent.context)
        var view= inflater.inflate(R.layout.myrecyclestruct,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(arr[position])
    }

    override fun getItemCount(): Int {
        return arr.size
    }
}
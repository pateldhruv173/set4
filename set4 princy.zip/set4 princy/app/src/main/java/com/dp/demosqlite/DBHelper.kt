package com.dp.demosqlite

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (var context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VER) {
    companion object{
        private val DB_NAME = "vehicleDB"
        private val TB_NAME ="vehicle"
        private val DB_VER = 1

        private val S1  = "Id"
        private val S2  = "vName"
        private val S3  = "millage"
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        var sql = "create table $TB_NAME ($S1 Integer Primary key AUTOINCREMENT, $S2 text, $S3 Integer)"

        p0?.execSQL(sql)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }

    fun insert(ve:vehicle) : Long
    {
        var db = writableDatabase
        var cv=   ContentValues()
        cv.put(S2,ve.vname)
        cv.put(S3,ve.millage)

        var result = db.insert(TB_NAME,null,cv)
        return result
    }
    fun RetrieveData() : ArrayList<vehicle>
    {
        var db = readableDatabase
        var arr = ArrayList<vehicle>()

        var cursor = db.query(TB_NAME,null,null,null,null,null,null,null)

        while(cursor.moveToNext())
        {
            var id = cursor.getInt(0)
            var vname = cursor.getString(1)
            var millage = cursor.getInt(2)

            var ve = vehicle(id,vname,millage)
            arr.add(ve)
        }

        return arr
    }

}
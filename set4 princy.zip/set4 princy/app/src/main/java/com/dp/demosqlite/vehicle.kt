package com.dp.demosqlite

data class vehicle constructor(var vname:String, var millage:Int){
    var id:Int = 0;
    constructor(id:Int,vname: String,millage:Int) :this(vname,millage)
    {
        this.id = id
    }
}